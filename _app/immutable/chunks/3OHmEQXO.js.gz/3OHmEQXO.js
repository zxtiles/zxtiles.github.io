import{w as a}from"./BiDevSN4.js";a();
