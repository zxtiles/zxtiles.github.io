import"./CWj6FrbW.js";import"./B0qky0ye.js";import{l as n,s as i,c as l,f as p,a as d,b as m}from"./o3m2f5Jq.js";import{I as $}from"./DE5PsA87.js";function v(o,s){const t=n(s,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z"}]];$(o,i({name:"message-circle"},()=>t,{get iconNode(){return a},children:(r,f)=>{var e=l(),c=p(e);d(c,s,"default",{}),m(r,e)},$$slots:{default:!0}}))}export{v as M};
