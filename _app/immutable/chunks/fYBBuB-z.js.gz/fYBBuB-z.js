import"./CWj6FrbW.js";import"./B0qky0ye.js";import{l as p,s as c,c as d,f as i,a as l,b as m}from"./o3m2f5Jq.js";import{I as $}from"./DE5PsA87.js";function v(s,t){const e=p(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["path",{d:"M18 6 6 18"}],["path",{d:"m6 6 12 12"}]];$(s,c({name:"x"},()=>e,{get iconNode(){return a},children:(r,f)=>{var o=d(),n=i(o);l(n,t,"default",{}),m(r,o)},$$slots:{default:!0}}))}export{v as X};
