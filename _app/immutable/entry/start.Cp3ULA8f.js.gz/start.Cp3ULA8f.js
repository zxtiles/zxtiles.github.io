import{a as r}from"../chunks/DNtQb4w1.js";import{x as t}from"../chunks/BaxoXI9J.js";export{t as load_css,r as start};
