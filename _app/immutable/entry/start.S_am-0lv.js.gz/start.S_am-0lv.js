import{a as r}from"../chunks/CGaIzacF.js";import{x as t}from"../chunks/BjHE4lFH.js";export{t as load_css,r as start};
