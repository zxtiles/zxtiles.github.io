import{a as r}from"../chunks/h7XxLpW6.js";import{x as t}from"../chunks/1HCTCFwd.js";export{t as load_css,r as start};
